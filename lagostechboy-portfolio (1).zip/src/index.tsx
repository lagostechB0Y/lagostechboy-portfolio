// This declaration allows us to access Vite's environment variables (like VITE_WP_API_URL)
// in a type-safe way. It extends the existing `ImportMetaEnv` interface.
declare global {
  interface ImportMetaEnv {
    readonly VITE_WP_API_URL?: string;
  }
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

// --- CONFIGURATION ---

// This is the heart of our connection to WordPress. We'll use the URL provided
// by Vercel's environment variables. If it's not available (like when running locally),
// we'll fall back to a stable public WordPress API for demonstration purposes.
const WP_API_URL = import.meta.env.VITE_WP_API_URL || 'https://wordpress.org/news/wp-json';


// --- DATA STRUCTURES ---
// These TypeScript interfaces define the shape of the data we expect from the WordPress API.
// This helps prevent bugs by ensuring we use the data correctly.

// Defines the structure for a single project.
interface WP_Project {
    id: number;
    slug: string;
    title: { rendered: string };
    // 'acf' fields are optional because they come from the Advanced Custom Fields plugin
    // and might not be present on the demo API's posts.
    acf?: {
        short_description: string;
        stack: string;
        description: string;
        live_url: string;
        repo_url: string;
    };
    // The 'excerpt' is a standard WordPress field we can use as a fallback if custom fields aren't available.
    excerpt?: {
        rendered: string;
    }
}

// Defines the structure for a WordPress page, like the "About Me" page.
interface WP_Page {
    content: { rendered: string };
    // The '_embedded' property contains linked data, like the featured image, if we request it.
    _embedded?: {
        'wp:featuredmedia'?: [{
            source_url: string;
            alt_text: string;
        }];
    };
}

// Defines the structure for our global site settings.
interface SiteOptions {
    logo_text: string;
    hero_title: string;
    hero_subtitle: string;
    contact: {
        email: string;
        linkedin: string;
        github: string;
    };
}

// This object provides default content for the site. It's used as a fallback
// if the custom API endpoint for site options isn't available or fails to load.
// This ensures the site always looks complete.
const DEFAULT_SITE_OPTIONS: SiteOptions = {
    logo_text: 'LTB',
    hero_title: 'Lagos|Tech|Boy',
    hero_subtitle: '> Software Engineer | WordPress & Laravel Specialist',
    contact: {
        email: 'hello@lagostechboy.dev',
        linkedin: 'lagostechboy',
        github: 'LagosTechBoy'
    }
};

// The main application logic starts once the HTML document is fully loaded.
document.addEventListener('DOMContentLoaded', () => {

    // This Map acts as a simple cache to store project data once it's been fetched.
    // This prevents us from having to re-fetch data for a project we've already seen.
    const allProjects = new Map<number, WP_Project>();
    const projectsPerPage = 3;
    let currentPage = 1;
    let totalPages = 1;

    // --- DOM Element References ---
    // We grab all the necessary DOM elements once at the start for better performance.
    const themeToggleBtn = document.getElementById('theme-toggle') as HTMLButtonElement;
    const docElement = document.documentElement;
    const projectViewerOverlay = document.getElementById('project-viewer-overlay') as HTMLElement;
    const projectViewerCloseBtn = document.getElementById('project-viewer-close') as HTMLButtonElement;
    const projectListEl = document.querySelector('.project-list');
    const prevBtn = document.getElementById('prev-btn') as HTMLButtonElement;
    const nextBtn = document.getElementById('next-btn') as HTMLButtonElement;
    const paginationControls = document.querySelector('.pagination-controls');

    // --- API Fetching Functions ---

    // A reusable wrapper around the native `fetch` API. It automatically adds the
    // base API URL and throws an error for non-successful responses (like 404s or 500s).
    const apiFetch = async (endpoint: string) => {
        const response = await fetch(`${WP_API_URL}${endpoint}`);
        if (!response.ok) {
            throw new Error(`Failed to fetch from ${endpoint}: ${response.statusText}`);
        }
        return response;
    };
    
    // Fetches a paginated list of projects. For the demo, it fetches standard blog posts.
    // It also reads the 'X-WP-TotalPages' header from the response to know how many pages are available.
    const fetchProjects = async (page = 1) => {
        // NOTE: When using your own backend, change '/wp/v2/posts' to your custom post type, e.g., '/wp/v2/projects'.
        const response = await apiFetch(`/wp/v2/posts?per_page=${projectsPerPage}&page=${page}&_embed`);
        const totalPagesHeader = response.headers.get('X-WP-TotalPages');
        const projects: WP_Project[] = await response.json();
        return { projects, totalPages: totalPagesHeader ? parseInt(totalPagesHeader, 10) : 1 };
    };

    // Fetches the content for the "About Me" page by its unique slug.
    const fetchAboutPage = async (): Promise<WP_Page> => {
        // NOTE: When using your own backend, change 'about-wordpress' to the slug of your "About" page, e.g., 'about'.
        const response = await apiFetch('/wp/v2/pages?slug=about-wordpress&_embed');
        const pages: WP_Page[] = await response.json();
        if (pages.length === 0) throw new Error("About page not found.");
        return pages[0];
    };
    
    // Attempts to fetch global site settings from a custom WordPress REST API endpoint.
    // It's designed to fail gracefully, returning `null` if the endpoint doesn't exist,
    // which allows the application to use the `DEFAULT_SITE_OPTIONS` fallback.
    const fetchSiteOptions = async (): Promise<SiteOptions | null> => {
        try {
            const response = await apiFetch('/v1/site-options');
            return await response.json();
        } catch (error) {
            console.warn("Could not fetch site options from custom endpoint. Using fallback data.", error);
            return null;
        }
    };


    // --- UI Rendering Functions ---

    // A simple utility to display an error message within a given container element.
    const renderErrorMessage = (container: Element | null, message: string) => {
        if (container) {
            container.innerHTML = `<p class="error-message" style="text-align: center; color: var(--secondary-text-color);">${message}</p>`;
        }
    };

    // Renders the list of projects for the current page.
    const renderProjects = (projects: WP_Project[]) => {
        if (!projectListEl) return;
        projectListEl.innerHTML = ''; // Clear out old projects or loading messages.

        if (projects.length === 0) {
            renderErrorMessage(projectListEl, "// No projects found.");
            return;
        }

        projects.forEach((project, index) => {
            allProjects.set(project.id, project); // Add the project to our cache.
            
            const projectEl = document.createElement('div');
            projectEl.className = 'project-item fade-in';
            projectEl.dataset.id = project.id.toString();
            projectEl.dataset.slug = project.slug;

            const projectNumber = (currentPage - 1) * projectsPerPage + index + 1;
            
            // We prioritize the custom field for the description, but fall back to the standard excerpt.
            const shortDesc = project.acf?.short_description || project.excerpt?.rendered.replace(/<[^>]*>?/gm, '').trim() || 'A project by LagosTechBoy.';

            projectEl.innerHTML = `
                <div class="project-header">
                    <span class="line-number">${projectNumber.toString().padStart(2, '0')}</span>
                    <h3>${project.title.rendered}</h3>
                    <p>${shortDesc}</p>
                    <button class="view-file-btn" aria-label="View details for ${project.title.rendered}">[ view file ]</button>
                </div>
            `;
            projectListEl.appendChild(projectEl);

            // This creates a subtle, staggered animation for the project list.
            setTimeout(() => projectEl.classList.add('visible'), 50 * index);
        });
    };

    // Populates the "About Me" section with content and the profile photo.
    const renderAboutContent = (page: WP_Page) => {
        const bioEl = document.querySelector('.bio');
        const photoEl = document.getElementById('about-photo') as HTMLImageElement;
        const photoPlaceholderEl = document.getElementById('about-photo-placeholder');
        
        if (bioEl) {
            bioEl.innerHTML = page.content.rendered;
        }

        const imageUrl = page._embedded?.['wp:featuredmedia']?.[0]?.source_url;
        if (photoEl && photoPlaceholderEl && imageUrl) {
            photoEl.src = imageUrl;
            photoEl.alt = page._embedded?.['wp:featuredmedia']?.[0]?.alt_text || 'A photo of LagosTechBoy';
            // We only show the image after it has fully loaded to prevent a flash of an empty element.
            photoEl.onload = () => {
                photoEl.style.display = 'block';
                photoPlaceholderEl.style.display = 'none';
            };
        }
    };
    
    // Renders the site's logo, hero text, and contact links.
    // It intelligently merges the fetched options with the default fallbacks.
    const renderSiteOptions = (options: SiteOptions | null) => {
        const mergedOptions = { 
            ...DEFAULT_SITE_OPTIONS, 
            ...options, 
            contact: { ...DEFAULT_SITE_OPTIONS.contact, ...options?.contact }
        };

        const logoEl = document.querySelector('.logo-placeholder');
        if (logoEl) logoEl.textContent = mergedOptions.logo_text;
    
        const heroTitleEl = document.querySelector('.ltb-title');
        if (heroTitleEl) {
            const parts = mergedOptions.hero_title.split('|');
            heroTitleEl.innerHTML = `
                <span class="ltb-part" style="--d: 0s;">${parts[0] || ''}</span>
                <span class="ltb-part" style="--d: 0.2s;">${parts[1] || ''}</span>
                <span class="ltb-part" style="--d: 0.4s;">${parts[2] || ''}</span>
                <span class="cursor" style="--d: 0.6s;">_</span>
            `;
        }
        
        const line2El = document.getElementById('typewriter-line2');
        if (line2El) {
            setTimeout(() => typeLine(line2El, mergedOptions.hero_subtitle), 1200);
        }
    
        const socialLinksEl = document.querySelector('.social-links');
        if (socialLinksEl) {
            const { email, linkedin, github } = mergedOptions.contact;
            socialLinksEl.innerHTML = `
                <a href="mailto:${email}" class="social-link" aria-label="Email">email(<span class="string-literal">"${email}"</span>)</a>
                <a href="https://linkedin.com/in/${linkedin}" class="social-link" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">linkedin(<span class="string-literal">"/in/${linkedin}"</span>)</a>
                <a href="https://github.com/${github}" class="social-link" target="_blank" rel="noopener noreferrer" aria-label="GitHub">github(<span class="string-literal">"/${github}"</span>)</a>
            `;
        }
    };
    

    // --- Application Core & Initialization ---

    // Handles fetching and rendering projects for a specific page.
    const loadAndRenderProjects = async (page: number) => {
        if(projectListEl) projectListEl.innerHTML = `<p style="text-align: center; color: var(--secondary-text-color);">// Loading projects...</p>`;
        try {
            const data = await fetchProjects(page);
            currentPage = page;
            totalPages = data.totalPages;
            renderProjects(data.projects);
            updatePaginationControls();
        } catch (error) {
            console.error("Failed to load projects:", error);
            renderErrorMessage(projectListEl, "// Could not load projects.");
        }
    };
    
    // This is the main function that kicks everything off.
    const initializeApp = async () => {
        // We use `Promise.allSettled` to make the initial load more resilient.
        // This allows one API call to fail without preventing the others from succeeding.
        // For example, if the "About" page fails to load, the "Projects" will still appear.
        const results = await Promise.allSettled([
            fetchSiteOptions(),
            fetchAboutPage()
        ]);

        const siteOptionsResult = results[0];
        if (siteOptionsResult.status === 'fulfilled') {
            renderSiteOptions(siteOptionsResult.value);
        } else {
            console.error("Failed to initialize site options:", siteOptionsResult.reason);
            renderSiteOptions(null); // Render with default fallbacks on error
        }

        const aboutDataResult = results[1];
        if (aboutDataResult.status === 'fulfilled') {
            renderAboutContent(aboutDataResult.value);
        } else {
            console.error("Failed to initialize about page content:", aboutDataResult.reason);
            renderErrorMessage(document.querySelector('.bio'), "// Could not load about content.");
        }
        
        // Load the first page of projects and check if we need to open one from the URL.
        await loadAndRenderProjects(currentPage);
        handleInitialHash();
    };

    // --- Theme Switcher ---
    // Manages the light/dark mode functionality.
    const applyTheme = (theme: 'light' | 'dark') => {
        docElement.setAttribute('data-theme', theme);
        try { localStorage.setItem('theme', theme); } catch (e) { console.warn('LocalStorage is not available.', e); }
    };
    const toggleTheme = () => applyTheme(docElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
    if (themeToggleBtn) themeToggleBtn.addEventListener('click', toggleTheme);
    // On load, we check for a saved theme in localStorage. If not found, we respect the user's OS preference.
    const savedTheme = (() => { try { return localStorage.getItem('theme') as 'light' | 'dark' | null; } catch (e) { return null; } })();
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (savedTheme) applyTheme(savedTheme); else if (prefersDark) applyTheme('dark'); else applyTheme('light');


    // --- Typewriter Effect ---
    // A simple function to simulate a typing effect for a given string.
    const typeLine = (element: HTMLElement, text: string, callback?: () => void) => {
        let i = 0;
        element.innerHTML = "";
        const typingInterval = setInterval(() => {
            if (i < text.length) {
                element.innerHTML += text.charAt(i);
                i++;
            } else {
                clearInterval(typingInterval);
                if (callback) callback();
            }
        }, 100);
    };

    // --- Project Viewer (Modal) Logic ---

    // Opens the project viewer modal and populates it with data from the cached `allProjects` map.
    const openProjectViewer = (projectId: number) => {
        const project = allProjects.get(projectId);
        if (!project) return;
        
        const filenameEl = projectViewerOverlay.querySelector('.project-viewer-filename span');
        const titleEl = document.getElementById('project-viewer-title');
        const stackListEl = document.getElementById('project-viewer-stack-list');
        const descriptionEl = document.getElementById('project-viewer-description');
        const liveLinkEl = document.getElementById('project-viewer-live-link') as HTMLAnchorElement;
        const repoLinkEl = document.getElementById('project-viewer-repo-link') as HTMLAnchorElement;

        if (filenameEl) filenameEl.textContent = `${project.slug}.md`;
        if (titleEl) titleEl.textContent = project.title.rendered;
        if (descriptionEl) descriptionEl.innerHTML = project.acf?.description || project.excerpt?.rendered || '';
        if (liveLinkEl) {
            liveLinkEl.href = project.acf?.live_url || '#';
            liveLinkEl.style.display = project.acf?.live_url ? 'inline-block' : 'none';
        }
        if (repoLinkEl) {
            repoLinkEl.href = project.acf?.repo_url || '#';
            repoLinkEl.style.display = project.acf?.repo_url ? 'inline-block' : 'none';
        }
        if (stackListEl && project.acf?.stack) {
            stackListEl.innerHTML = '';
            project.acf.stack.split(',').forEach(tech => {
                const li = document.createElement('li');
                li.textContent = tech.trim();
                stackListEl.appendChild(li);
            });
        }
        
        document.body.classList.add('project-view-active'); // Used to freeze background scroll.
        projectViewerOverlay.classList.add('visible');
        projectViewerOverlay.setAttribute('aria-hidden', 'false');
        
        // Update the URL hash for deep-linking, allowing users to share a link directly to a project.
        const newHash = `#work/${project.slug}`;
        if (window.location.hash !== newHash) {
            // `pushState` is preferred as it doesn't create a new history entry for the user.
            try { history.pushState(null, '', newHash); } catch (e) { location.hash = newHash; }
        }
    };
    
    // Closes the project viewer and cleans up the URL hash.
    const closeProjectViewer = () => {
        document.body.classList.remove('project-view-active');
        projectViewerOverlay.classList.remove('visible');
        projectViewerOverlay.setAttribute('aria-hidden', 'true');
        if (window.location.hash.startsWith('#work/')) {
            // Remove the hash from the URL without reloading the page.
            try { history.pushState('', document.title, window.location.pathname + window.location.search); } catch (e) { window.location.hash = ''; }
        }
    };

    // Event listener for the main project list to handle clicks on "view file" buttons.
    if (projectListEl) {
        projectListEl.addEventListener('click', (e) => {
            const target = e.target as HTMLElement;
            const viewBtn = target.closest('.view-file-btn');
            if (viewBtn) {
                e.preventDefault();
                const projectItem = viewBtn.closest('.project-item') as HTMLElement;
                const projectId = projectItem.dataset.id;
                if (projectId) {
                    openProjectViewer(parseInt(projectId, 10));
                }
            }
        });
    }

    // Event listeners for closing the modal.
    if (projectViewerCloseBtn) projectViewerCloseBtn.addEventListener('click', closeProjectViewer);
    window.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeProjectViewer(); });
    projectViewerOverlay.addEventListener('click', (e) => { if (e.target === projectViewerOverlay) closeProjectViewer(); });
    
    // --- URL Hash-based Routing ---
    // This allows for deep-linking directly to a project.
    const handleHashChange = async () => {
        const hash = window.location.hash;
        const projectSlug = hash.startsWith('#work/') ? hash.substring(6) : null;
        
        if (projectSlug) {
            // Only proceed if the viewer isn't already open with this project.
            if (!document.body.classList.contains('project-view-active')) {
                // First, check if we've already cached the project.
                let projectToOpen: WP_Project | undefined;
                for (const p of allProjects.values()) {
                    if (p.slug === projectSlug) { projectToOpen = p; break; }
                }

                if (projectToOpen) {
                    openProjectViewer(projectToOpen.id);
                } else {
                    // If not cached, fetch it directly from the API by its slug.
                    try {
                        // NOTE: Uses '/posts' for demo. Change to '/projects' for your site.
                        const response = await apiFetch(`/wp/v2/posts?slug=${projectSlug}&_embed`);
                        const projects: WP_Project[] = await response.json();
                        if (projects.length > 0) {
                            const project = projects[0];
                            allProjects.set(project.id, project); // Cache it for next time.
                            openProjectViewer(project.id);
                        }
                    } catch (e) { console.error('Failed to fetch project by slug', e); }
                }
            }
        } else if (document.body.classList.contains('project-view-active')) {
            // If the hash is removed, close the viewer.
            closeProjectViewer();
        }
    };
    
    // Listen for changes in the URL hash.
    window.addEventListener('hashchange', handleHashChange);
    // Check the hash when the page first loads.
    const handleInitialHash = () => {
        if (window.location.hash.startsWith('#work/')) {
            setTimeout(handleHashChange, 100); // Small delay to ensure content is ready.
        }
    };
    
    // --- Project Pagination ---
    // Manages the visibility and state of the "Next" and "Prev" buttons.
    const updatePaginationControls = () => {
        if (!paginationControls) return;

        if (totalPages <= 1) {
            (paginationControls as HTMLElement).style.display = 'none';
        } else {
            (paginationControls as HTMLElement).style.display = 'flex';
            if (prevBtn) prevBtn.disabled = currentPage === 1;
            if (nextBtn) nextBtn.disabled = currentPage >= totalPages;
        }
    };

    if (nextBtn) nextBtn.addEventListener('click', () => {
        if (currentPage < totalPages) loadAndRenderProjects(currentPage + 1);
    });
    if (prevBtn) prevBtn.addEventListener('click', () => {
        if (currentPage > 1) loadAndRenderProjects(currentPage - 1);
    });
    
    // --- Miscellaneous UI Enhancements ---

    // Use the Intersection Observer API for performant fade-in animations on scroll.
    const fadeObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target); // We only need to animate it once.
            }
        });
    }, { root: null, rootMargin: '0px', threshold: 0.1 });
    document.querySelectorAll('.fade-in').forEach(elem => fadeObserver.observe(elem));

    // Smooth scrolling for on-page anchor links.
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (this: HTMLAnchorElement, e: MouseEvent) {
            const href = this.getAttribute('href');
            // We ignore the project viewer links, as they are handled by the hash-routing logic.
            if (href && href.startsWith('#work/')) return;
            e.preventDefault();
            if (href) {
                const targetElement = document.querySelector(href);
                if (targetElement) targetElement.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // Use Intersection Observer to highlight the active navigation link based on the currently viewed section.
    const sections = document.querySelectorAll('main > section');
    const navLinks = document.querySelectorAll('.main-nav a');
    const headerHeight = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--header-height'));
    const navObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const id = entry.target.getAttribute('id');
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${id}`) link.classList.add('active');
                });
            }
        });
    }, { root: null, rootMargin: `-${headerHeight}px 0px -40% 0px`, threshold: 0 });
    sections.forEach(section => { if (section.id) navObserver.observe(section); });

    // Logic for the "scroll to top" button.
    const scrollToTopBtn = document.getElementById('scroll-to-top') as HTMLButtonElement;
    if (scrollToTopBtn) {
        window.addEventListener('scroll', () => {
            scrollToTopBtn.classList.toggle('visible', window.scrollY > window.innerHeight / 2);
        });
        scrollToTopBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
    }

    // --- Start the App ---
    initializeApp();
});

// This empty export is a TypeScript quirk. It tells the compiler to treat this file
// as a module, which is necessary for the `declare global` block at the top to work correctly.
export {};
